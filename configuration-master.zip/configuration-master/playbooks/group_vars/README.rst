After EC2 discovery variables in the files that match any of the discovered
groups will be set.

For convenience a single variable is set for every Group tag for conditional
task execution.
